/*
 * Kodun dry prensibini kontrol et.
 */


#include <string.h>
#include <omnetpp.h>
#include <algorithm>
#include "layer_m.h"

using namespace omnetpp;

class Node : public cSimpleModule
{
    protected:
	cGate* parent_gate;
    int my_layer;
    std::vector< cGate* > childs;
    std::vector< cGate* > others;
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
    virtual void refreshDisplay() const override;
    virtual void finish() override;

    private:
    virtual Layer *createLayerMsg(int layer);
    virtual void sendLayerMessage(int sender);
    virtual void showArray(std::vector< cGate* > array, char *text) const;
    virtual void handleLayerMessage(Layer *msg, cGate *sender);
	virtual void handleAckMessage(cMessage *msg, cGate *sender);
	virtual void handleRejectMessage(cMessage *msg, cGate *sender);
	virtual void handleDeleteMessage(cGate *sender);
};

Define_Module(Node);

void Node::initialize()
{
    parent_gate = NULL;                                         // Bütün nodeların parentlarını NULL ata.
    my_layer = int(std::numeric_limits<double>::infinity());    // Bütün nodeların layerlarını sonsuz ata.
    WATCH(my_layer);

    if(getIndex() == 0){										// Kök düğüm algoritmayı başlatıyor.
        my_layer = 0;
        sendLayerMessage(-1);
    }
}

void Node::handleMessage(cMessage *msg)
{
	cGate* sender = msg->getArrivalGate();
    if(strcmp(msg->getName(), "layer") == 0){
        Layer *lyrmsg = check_and_cast<Layer *>(msg);           // Mesajın layer türünde olduğunu belirtiyoruz.
        handleLayerMessage(lyrmsg, sender);
    }else if(strcmp(msg->getName(), "ack") == 0){
		handleAckMessage(msg, sender);
    }else if(strcmp(msg->getName(), "reject") == 0){
		handleRejectMessage(msg, sender);
    }else{
        handleDeleteMessage(sender);
    }
    delete msg;
}

void Node::finish()
{
    char ctext[] = "'s childs:";
    showArray(childs, ctext);
    char otext[] = "'s others: ";
    showArray(others, otext);
}

Layer *Node::createLayerMsg(int layer)
{
    Layer *msg = new Layer("layer");                            // Layer mesajını oluştur
    msg->setLayer(layer);                                       // Katmanı ata
    msg->setSource(getIndex());                                 // Kaynağı ata
    return msg;
}

void Node::sendLayerMessage(int sender)
{
    for(int i = 0; i < gateSize("gate"); i++){
        if(i == sender){continue;}                              // Gönderen hariç
        send(createLayerMsg(my_layer+1), "gate$o", i);
    }
}

void Node::handleLayerMessage(Layer *msg, cGate *sender)
{
    if(msg->getLayer() < my_layer && parent_gate == NULL){      // İlk defa layer mesajı alıyorum ve katman bilgisi küçük
        parent_gate = sender;                                               // Mesajın geldiği kapıyı ebeveyn olarak atıyoruz.
        my_layer = msg->getLayer();                                         // Yeni katman mesajdaki katman bilgisi.
        send(new cMessage("ack", 2), "gate$o", sender->getIndex());         // Gönderene ACK mesajı.
        sendLayerMessage(sender->getIndex());
    }else if(msg->getLayer() < my_layer && parent_gate != NULL){ // İlk defa layer mesajı almıyorum ama yeni gelen katman bilgisi daha küçük
        send(new cMessage("sil", 4), "gate$o", parent_gate->getIndex());
        parent_gate = sender;
        my_layer = msg->getLayer();
        send(new cMessage("ack", 2), "gate$o", sender->getIndex());
        sendLayerMessage(sender->getIndex());
    }else{
        send(new cMessage("reject", 1), "gate$o", sender->getIndex());      // Gönderene Reject mesajı.
    }
}

void Node::handleAckMessage(cMessage *msg, cGate *sender)
{
    bubble("ACK mesajı aldım");
    if(std::find(childs.begin(), childs.end(), sender) == childs.end()){    // Eğer çocuklarda değilse
        childs.push_back(sender);                                           // Çocuklara ekliyoruz.
    }
    if(std::find(others.begin(), others.end(), sender) != others.end()){    // Eğer diğerlerinde varsa
        others.erase(std::find(others.begin(), others.end(), sender));      // Diğerlerinden çıkartıyoruz.
    }
}

void Node::handleRejectMessage(cMessage *msg, cGate *sender)
{
	bubble("Reject mesajı aldım");
	if(std::find(others.begin(), others.end(), sender) == others.end()){    // Eğer diğerlerinde değilse
	    others.push_back(sender);              					            // Diğerlerine ekliyoruz.
	}
}

void Node::handleDeleteMessage(cGate *sender)
{
    if(std::find(childs.begin(), childs.end(), sender) != childs.end()){
        childs.erase(std::find(childs.begin(), childs.end(), sender));
    }
}

void Node::showArray(std::vector< cGate* > array, char *text) const
{
    EV << this->getFullName() << text;
    for(std::size_t i = 0; i < array.size(); i++){
        EV << array.at(i)->getPreviousGate()->getOwner()->getFullName() << "  ";
    }
    EV << "\n";
}

void Node::refreshDisplay() const
{
    char buf[20];
    sprintf(buf, "Layer: %d", my_layer);
    getDisplayString().setTagArg("t", 0, buf);
}
