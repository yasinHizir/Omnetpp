/*
 * node.cc
 *
 *  Created on: Apr 18, 2020
 *      Author: YasinHIZIR
 */

#include <string.h>
#include <omnetpp.h>
#include <algorithm>

using namespace omnetpp;

class Node : public cSimpleModule
{
    protected:
        cGate* parent_gate;
        std::vector< cGate* > childs;
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
        virtual void finish() override;

    private:
        virtual void handleProbeMessage(cMessage *msg, cGate *sender);
        virtual void handleAckMessage(cMessage *msg, cGate *sender);
        virtual void handleRejectMessage(cMessage *msg, cGate *sender);
};

Define_Module(Node);

void Node::initialize()
{
    parent_gate = NULL;                                                     // Bütün nodeların parentlarını NULL ata.

    if(getIndex() == 0) {                                                   // Kök düğüm algoritmayı başlatıyor.
        for(int i = 0; i < gateSize("gate"); i++) {
            send(new cMessage("probe"), "gate$o", i);                       // Bütün komşularına probe mesajı gönderiyor.
        }
    }
}

void Node::handleMessage(cMessage *msg)
{
    cGate* sender = msg->getArrivalGate();
    if(strcmp(msg->getName(), "probe") == 0){                               // Eğer alınan mesaj probe ise
        handleProbeMessage(msg, sender);

    }else if(strcmp(msg->getName(), "ack") == 0){                           // Eğer alınan mesaj ack ise
        handleAckMessage(msg, sender);
    }else if(strcmp(msg->getName(), "reject") == 0){                        // Eğer alınan mesaj reject ise
        handleRejectMessage(msg, sender);
    }else{
        EV << "Mesajın kimliği belirlenemedi.";
    }
    delete msg;                                                             // Gelen mesaj silinir.
}

void Node::handleProbeMessage(cMessage *msg, cGate *sender)
{
    if(parent_gate == NULL){                                                // Ebevnyni yoksa
        parent_gate = sender;                                               // Mesajı göndereni ebevyn olarak atayacak.
        send(new cMessage("ack", 2), "gate$o", sender->getIndex());         // Mesajı gönderene ack mesajı gönderiyoruz.
        for(int i = 0; i < gateSize("gate"); i++){
            if(i == sender->getIndex()){continue;}
            send(new cMessage("probe"), "gate$o", i);                       // Gönderen hariç herkese probe mesajı gönderiyoruz.
        }
    }else{                                                                  // Ebevyni varsa
        send(new cMessage("reject", 1), "gate$o", sender->getIndex());      // Mesajı gönderene reject mesajı gönderiyoruz.
    }
}

void Node::handleAckMessage(cMessage *msg, cGate *sender)
{
    bubble("ACK mesajı aldım");
    if(std::find(childs.begin(), childs.end(), sender) == childs.end()){    // Eğer çocuklarda değilse
        childs.push_back(sender);                                           // Çocuklara ekliyoruz.
    }
}

void Node::handleRejectMessage(cMessage *msg, cGate *sender)
{
    bubble("Reject mesajı aldım");
}

void Node::finish()
{
    EV << this->getFullName() << "'s childs: ";
    for(std::size_t i = 0; i < childs.size(); i++){
        EV << childs.at(i)->getPreviousGate()->getOwner()->getFullName() << "  ";
    }
    EV << "\n";
}
